    <style>
        .science-section {
            background-color: rgb(2, 32, 74);
            color: whitesmoke; /* deemwhite equivalent */
            padding: 100px 0;
            min-height: 400px;
            width: 100%;
        }
        .science-content {
            max-width: 1320px;
            margin: 0 auto;
        }
        .lead{
            color: #fff !important;
        }
    </style>
    <!-- Science & Technology Section -->
    <section class="science-section">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <center>
                    <div class="col-12 science-content">
                    <h1 class="display-4 mb-4">Advanced Antibody Engineering</h1>
                    <p class="lead">
                        We use state-of-the-art techniques to design and optimize mAbs for maximum precision, potency, and safety.
                    </p>
                </div>
                </center>
            </div>
        </div>
    </section>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>