<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Science & Technology - Therapeutic Antibody Platform</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <!-- header -->
<section>
    <?php include "header.php"; ?>
</section>

<!-- Main Content -->
    <main class="container-fluid">
        <?php include "sections/science-and-technology-slider.php"; ?>
        <section class="container-fluid">
            <?php include'sections/science-and-technology-section-1.php';?>
            <?php include'sections/science-and-technology-section-2.php';?>
            <!-- <?php #include 'sections/science-and-technology-section-3.php';?> -->
            <?php include'sections/science-and-technology-section-4.php';?>
             <?php include'sections/science-and-technology-section-5.php';?>
            <!-- <?php #include('templates/science-and-technology.php'); ?> -->
        </section>
    </main>

    <!-- Footer -->
    <footer class=" container-fluid bg-light">
     <?php include "footer.php"; ?>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<style>
    /* Page Header Strip */
.page-header-strip {
    background-color: #124170;
    color: white;
    padding: 15px 0;
    margin-bottom: 40px;
}

.page-header-strip .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.breadcrumb {
    font-size: 14px;
}

.breadcrumb a {
    color: white;
    text-decoration: none;
}

.breadcrumb a:hover {
    text-decoration: underline;
}

.page-title {
    font-size: 18px;
    font-weight: bold;
    text-transform: uppercase;
}

</style>